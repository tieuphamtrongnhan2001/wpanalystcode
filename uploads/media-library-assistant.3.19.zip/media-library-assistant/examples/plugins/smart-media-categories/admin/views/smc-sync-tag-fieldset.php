<?php
/*
 * Tag Fieldset Parameters
 *
 * $tag_blocks sequence of flat taxonomy text areas
 */
?>
<fieldset class="smc-sync-col-right">
	<div class="smc-sync-col" id="smc-sync-tag-blocks">
		<?php echo $tag_blocks; ?>
	</div>
</fieldset>

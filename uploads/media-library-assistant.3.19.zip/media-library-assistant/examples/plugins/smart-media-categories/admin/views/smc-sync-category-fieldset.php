<?php
/*
 * Category Fieldset Parameters
 *
 * $category_blocks sequence of hierarchical taxonomy checkbox lists
 */
?>
<fieldset class="smc-sync-col-center smc-sync-categories">
	<div class="smc-sync-col" id="smc-sync-category-blocks">
		<?php echo $category_blocks; ?>
	</div>
</fieldset>

/* global soliloquy_metabox, uploader, QTags, quicktags */
/**
* You'll need to use CodeKit or similar, as this file is a placeholder to combine
* the following JS files into min/metabox-min.js:
*
* - slider-helper.js
* - slider-types.js
* - media-delete.js
* - media-edit.js
* - media-insert.js
* - media-manage.js
* - media-upload.js
*/
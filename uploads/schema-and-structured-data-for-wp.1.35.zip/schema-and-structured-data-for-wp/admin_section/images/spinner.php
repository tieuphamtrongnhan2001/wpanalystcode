<?php 
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<span class="merlin__button--loading__spinner">
<cite class="merlin-spinner"><!--
--><cite class="merlin-spinner-line merlin-spinner-line--1"><!--
--><cite class="merlin-spinner-line-cog"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--left"></cite><!--
--></cite><!--
--><cite class="merlin-spinner-line-ticker"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--center"></cite><!--
--></cite><!--
--><cite class="merlin-spinner-line-cog"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--right"></cite><!--
--></cite><!--
--></cite><!--
--><cite class="merlin-spinner-line merlin-spinner-line--2"><!--
--><cite class="merlin-spinner-line-cog"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--left"></cite><!--
--></cite><!--
--><cite class="merlin-spinner-line-ticker"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--center"></cite><!--
--></cite><!--
--><cite class="merlin-spinner-line-cog"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--right"></cite><!--
--></cite><!--
--></cite><!--
--><cite class="merlin-spinner-line merlin-spinner-line--3"><!--
--><cite class="merlin-spinner-line-cog"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--left"></cite><!--
--></cite><!--
--><cite class="merlin-spinner-line-ticker"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--center"></cite><!--
--></cite><!--
--><cite class="merlin-spinner-line-cog"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--right"></cite><!--
--></cite><!--
--></cite><!--
--><cite class="merlin-spinner-line merlin-spinner-line--4"><!--
--><cite class="merlin-spinner-line-cog"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--left"></cite><!--
--></cite><!--
--><cite class="merlin-spinner-line-ticker"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--center"></cite><!--
--></cite><!--
--><cite class="merlin-spinner-line-cog"><!--
--><cite class="merlin-spinner-line-cog-inner merlin-spinner-line-cog-inner--right"></cite><!--
--></cite><!--
--></cite><!--
--></cite><!--/spinner -->
</span>
<?php 
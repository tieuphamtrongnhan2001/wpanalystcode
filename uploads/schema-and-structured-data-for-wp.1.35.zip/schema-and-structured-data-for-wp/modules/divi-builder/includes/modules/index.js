import FaqBlock from './FaqBlock/FaqBlock';
export default [FaqBlock];
   
//import HelloWorld from './HelloWorld/HelloWorld';
//export default [HelloWorld];

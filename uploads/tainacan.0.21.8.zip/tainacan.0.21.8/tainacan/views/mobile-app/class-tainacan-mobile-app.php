<?php

namespace Tainacan;

class Mobile_App {

	public function __construct(){}

	public function admin_page()
	{
		include('admin-page.php');
	}
}
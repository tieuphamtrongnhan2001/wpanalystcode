<div class="wrap">
	<h1>
		<?php _e('Mobile App', 'tainacan'); ?>
	</h1>
</div>